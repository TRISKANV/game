package com.kotlinsurvivors.engine.ecs.systems

import com.kotlinsurvivors.engine.ecs.EntityFactory
import com.kotlinsurvivors.engine.ecs.World
import com.kotlinsurvivors.engine.ecs.components.EnemyType
import com.kotlinsurvivors.engine.map.LevelMap
import kotlin.math.*
import kotlin.random.Random

/**
 * SpawnSystem
 *
 * Memory fixes:
 *  1. buildEnemyPool() and pickBossType() no longer allocate new lists on
 *     every spawn check — they use pre-built fixed arrays indexed at construction.
 *  2. randomSpawnPosition() returns floats directly instead of Pair<Float,Float>.
 *  3. absoluteMaxEnemies kept at 300 (was 800) to bound memory usage.
 */
class SpawnSystem(
    private val viewportWidth : Float,
    private val viewportHeight: Float
) {

    private var spawnTimer       = 0f
    private var bossTimer        = 0f
    private var waveTimer        = 0f
    private var currentWave      = 0
    private var spawnInterval    = 1.2f
    private val minSpawnInterval = 0.25f  // raised from 0.18 to reduce peak entity count
    private var maxEnemies       = 50     // lowered starting cap
    private val absoluteMaxEnemies = 300  // lowered from 800 to prevent OOM
    private val bossInterval     = 180f

    // Pre-built pool arrays — allocated once, never recreated
    // Level 1 only has guards (BASIC) and drones (FAST) as regular enemies; K9 patrols and the
    // bosses come from the event director. The other types stay in the engine for later levels.
    private val poolEarly  = arrayOf(EnemyType.BASIC, EnemyType.BASIC, EnemyType.BASIC)
    private val poolMid    = arrayOf(EnemyType.BASIC, EnemyType.BASIC, EnemyType.FAST)
    private val poolLate   = arrayOf(EnemyType.BASIC, EnemyType.BASIC, EnemyType.BASIC,
                                     EnemyType.FAST,  EnemyType.FAST)
    private val bossList   = arrayOf(EnemyType.BOSS_SHADOW, EnemyType.BOSS_GOLEM, EnemyType.BOSS_NECROMANCER)

    /** Chance that an ordinary spawn is a riot officer (level 2, once the station is cleared). */
    var riotShare: Float = 0f

    /** Collision grid of the current level; enemies only appear on free ground. */
    var levelMap: LevelMap? = null

    /**
     * Looks for a free spot just outside the screen around the player, for the special events.
     * On success [spawnPointX] / [spawnPointY] hold it.
     */
    fun findSpawnPoint(px: Float, py: Float): Boolean = pickSpawnPosition(px, py)
    val spawnPointX: Float get() = spawnX
    val spawnPointY: Float get() = spawnY

    /** How much stronger enemies are [elapsed] seconds into the run. */
    fun difficultyAt(elapsed: Float): Float = waveMultiplier(elapsed)

    // Reusable spawn position — avoids Pair allocation every spawn
    private var spawnX = 0f
    private var spawnY = 0f

    fun update(world: World, dt: Float, elapsedTime: Float): SpawnResult {
        val result       = SpawnResult()
        val playerEntity = world.getPlayerEntity()
        if (playerEntity == -1) return result

        val pt = world.transforms[playerEntity] ?: return result

        // Scale enemy cap with time, hard-capped at absoluteMaxEnemies
        maxEnemies = (50 + (elapsedTime / 60f) * 50f).toInt().coerceAtMost(absoluteMaxEnemies)

        // Scale spawn interval
        val progress  = (elapsedTime / 1200f).coerceIn(0f, 1f)
        spawnInterval = lerp(1.2f, minSpawnInterval, progress * progress)

        // Wave timer
        waveTimer += dt
        if (waveTimer >= 30f) { waveTimer = 0f; currentWave++; result.newWave = currentWave }

        // Regular spawns
        spawnTimer += dt
        if (spawnTimer >= spawnInterval) {
            spawnTimer = 0f
            val currentCount = world.getEnemyEntities().size
            if (currentCount < maxEnemies) {
                val burst = spawnBurstCount(elapsedTime)
                repeat(burst) {
                    if (world.getEnemyEntities().size < maxEnemies) {
                        if (pickSpawnPosition(pt.x, pt.y)) {
                            val type = pickEnemyType(elapsedTime)
                            EntityFactory.createEnemy(world, type, spawnX, spawnY, waveMultiplier(elapsedTime))
                            result.enemiesSpawned++
                        }
                    }
                }
            }
        }

        // Boss spawns
        bossTimer += dt
        if (bossTimer >= bossInterval && pickSpawnPosition(pt.x, pt.y)) {
            bossTimer = 0f
            val bossType = pickBossType(elapsedTime)
            val mult = (1f + elapsedTime / 180f).coerceAtMost(4f)
            EntityFactory.createEnemy(world, bossType, spawnX, spawnY, mult)
            result.bossSpawned = true
        }

        return result
    }

    private fun spawnBurstCount(elapsed: Float) = when {
        elapsed < 60f  -> 1
        elapsed < 180f -> 2
        elapsed < 360f -> 3
        else           -> 4  // was up to 10 — reduced to control entity count
    }

    private fun pickEnemyType(elapsed: Float): EnemyType {
        if (riotShare > 0f && Random.nextFloat() < riotShare) return EnemyType.RIOT
        val pool = when {
            elapsed < 30f  -> poolEarly
            elapsed < 120f -> poolMid
            else           -> poolLate
        }
        return pool[Random.nextInt(pool.size)]
    }

    private fun pickBossType(elapsed: Float): EnemyType {
        val count = when {
            elapsed < 180f -> 1
            elapsed < 360f -> 2
            else           -> 3
        }
        return bossList[Random.nextInt(count)]
    }

    private fun waveMultiplier(elapsed: Float) = 1f + (elapsed / 120f) * 0.5f

    /**
     * Like [calcSpawnPosition] but, on a level with obstacles, retries a few times until the
     * spot is free ground. False when none was found (the caller skips this spawn and tries
     * again on the next one; the player may be standing next to the edge of the map).
     */
    private fun pickSpawnPosition(px: Float, py: Float): Boolean {
        val map = levelMap
        if (map == null) { calcSpawnPosition(px, py); return true }
        // The camera stops at the edge of the map, so the player is not always in the middle
        // of the screen: work out what is really visible and never spawn inside it.
        val camX = (px - viewportWidth  * 0.5f).coerceIn(0f, (map.worldSize - viewportWidth ).coerceAtLeast(0f))
        val camY = (py - viewportHeight * 0.5f).coerceIn(0f, (map.worldSize - viewportHeight).coerceAtLeast(0f))
        repeat(SPAWN_TRIES) {
            calcSpawnPosition(px, py)
            val onScreen = spawnX > camX - OFFSCREEN_MARGIN && spawnX < camX + viewportWidth  + OFFSCREEN_MARGIN &&
                           spawnY > camY - OFFSCREEN_MARGIN && spawnY < camY + viewportHeight + OFFSCREEN_MARGIN
            if (!onScreen && map.isBoxFree(spawnX, spawnY, SPAWN_CLEARANCE, SPAWN_CLEARANCE)) return true
        }
        return false
    }

    /**
     * Writes spawn position into spawnX/spawnY instead of returning Pair.
     * Eliminates one Pair allocation per spawn event.
     */
    private fun calcSpawnPosition(px: Float, py: Float) {
        val margin = 80f
        val halfW  = viewportWidth  * 0.5f + margin
        val halfH  = viewportHeight * 0.5f + margin
        when (Random.nextInt(4)) {
            0 -> { spawnX = px + Random.nextFloat()*halfW*2f - halfW; spawnY = py - halfH }
            1 -> { spawnX = px + halfW; spawnY = py + Random.nextFloat()*halfH*2f - halfH }
            2 -> { spawnX = px + Random.nextFloat()*halfW*2f - halfW; spawnY = py + halfH }
            else -> { spawnX = px - halfW; spawnY = py + Random.nextFloat()*halfH*2f - halfH }
        }
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun reset() {
        spawnTimer = 0f; bossTimer = 0f; waveTimer = 0f
        currentWave = 0; spawnInterval = 1.2f; maxEnemies = 50
    }

    private companion object {
        const val SPAWN_TRIES     = 30
        const val OFFSCREEN_MARGIN = 60f   // the camera lags a little behind the player
        const val SPAWN_CLEARANCE = 20f   // enough room for any enemy, bosses may squeeze out of it
    }

    data class SpawnResult(
        var enemiesSpawned: Int = 0,
        var bossSpawned: Boolean = false,
        var newWave: Int = -1
    )
}
